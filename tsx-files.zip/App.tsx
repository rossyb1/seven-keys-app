import React from 'react';
import { View, ActivityIndicator } from 'react-native';
import { NavigationContainer } from '@react-navigation/native';
import { createNativeStackNavigator } from '@react-navigation/native-stack';
import { BackgroundColors, AccentColors } from './constants/brand';
import { useAppFonts } from './hooks/useAppFonts';
import { AuthProvider, useAuth } from './src/contexts/AuthContext';
import SplashScreen from './app/SplashScreen';
import InviteCodeScreen from './app/InviteCodeScreen';
import SignUpScreen from './app/SignUpScreen';
import CitySelectionScreen from './app/CitySelectionScreen';
import AgeGroupScreen from './app/AgeGroupScreen';
import PermissionsScreen from './app/PermissionsScreen';
import WelcomeScreen from './app/WelcomeScreen';
import MainTabs from './app/MainTabs';
import VenueDetailScreen from './app/screens/VenueDetailScreen';
import CategoryVenuesScreen from './app/screens/CategoryVenuesScreen';
import SelectDateScreen from './app/booking/SelectDateScreen';
import SelectTimeScreen from './app/booking/SelectTimeScreen';
import PartySizeScreen from './app/booking/PartySizeScreen';
import TablePreferenceScreen from './app/booking/TablePreferenceScreen';
import SpecialRequestsScreen from './app/booking/SpecialRequestsScreen';
import ReviewBookingScreen from './app/booking/ReviewBookingScreen';
import BookingSubmittedScreen from './app/booking/BookingSubmittedScreen';
import RunningLateScreen from './app/booking/RunningLateScreen';
import CancelBookingScreen from './app/booking/CancelBookingScreen';
import BookingDetailScreen from './app/screens/BookingDetailScreen';
import SevenKCardScreen from './app/screens/SevenKCardScreen';
import PersonalDetailsScreen from './app/settings/PersonalDetailsScreen';
import PreferredCitiesScreen from './app/settings/PreferredCitiesScreen';
import NotificationSettingsScreen from './app/settings/NotificationSettingsScreen';
import PointsHistoryScreen from './app/settings/PointsHistoryScreen';
import PaymentMethodsScreen from './app/settings/PaymentMethodsScreen';
import FAQsScreen from './app/settings/FAQsScreen';
import MessageConciergeScreen from './app/screens/MessageConciergeScreen';
import ChangeTimeScreen from './app/booking/ChangeTimeScreen';
import ChangeDateScreen from './app/booking/ChangeDateScreen';
import AddGuestsScreen from './app/booking/AddGuestsScreen';
import WelcomeHomeScreen from './src/screens/main/WelcomeHomeScreen';

const Stack = createNativeStackNavigator();

// Auth Stack - for unauthenticated users
function AuthStack() {
  return (
    <Stack.Navigator
      screenOptions={{
        headerShown: false,
        contentStyle: {
          backgroundColor: BackgroundColors.primary,
        },
      }}
    >
      <Stack.Screen name="Splash" component={SplashScreen} />
      <Stack.Screen name="InviteCode" component={InviteCodeScreen} />
      <Stack.Screen name="SignUp" component={SignUpScreen} />
      <Stack.Screen name="CitySelection" component={CitySelectionScreen} />
      <Stack.Screen name="AgeGroup" component={AgeGroupScreen} />
      <Stack.Screen name="Permissions" component={PermissionsScreen} />
      <Stack.Screen name="Welcome" component={WelcomeScreen} />
    </Stack.Navigator>
  );
}

// App Stack - for authenticated users
function AppStack() {
  return (
    <Stack.Navigator
      screenOptions={{
        headerShown: false,
        contentStyle: {
          backgroundColor: BackgroundColors.primary,
        },
      }}
      initialRouteName="WelcomeHome"
    >
      <Stack.Screen name="WelcomeHome" component={WelcomeHomeScreen} />
      <Stack.Screen name="MainTabs" component={MainTabs} />
      <Stack.Screen name="CategoryVenues" component={CategoryVenuesScreen} />
      <Stack.Screen name="VenueDetail" component={VenueDetailScreen} />
      <Stack.Screen name="SelectDate" component={SelectDateScreen} />
      <Stack.Screen name="SelectTime" component={SelectTimeScreen} />
      <Stack.Screen name="PartySize" component={PartySizeScreen} />
      <Stack.Screen name="TablePreference" component={TablePreferenceScreen} />
      <Stack.Screen name="SpecialRequests" component={SpecialRequestsScreen} />
      <Stack.Screen name="ReviewBooking" component={ReviewBookingScreen} />
      <Stack.Screen name="BookingSubmitted" component={BookingSubmittedScreen} />
      <Stack.Screen name="BookingDetail" component={BookingDetailScreen} />
      <Stack.Screen name="RunningLate" component={RunningLateScreen} />
      <Stack.Screen name="CancelBooking" component={CancelBookingScreen} />
      <Stack.Screen name="SevenKCard" component={SevenKCardScreen} />
      <Stack.Screen name="PersonalDetails" component={PersonalDetailsScreen} />
      <Stack.Screen name="PreferredCities" component={PreferredCitiesScreen} />
      <Stack.Screen name="NotificationSettings" component={NotificationSettingsScreen} />
      <Stack.Screen name="PointsHistory" component={PointsHistoryScreen} />
      <Stack.Screen name="PaymentMethods" component={PaymentMethodsScreen} />
      <Stack.Screen name="FAQs" component={FAQsScreen} />
      <Stack.Screen name="MessageConcierge" component={MessageConciergeScreen} />
      <Stack.Screen name="ChangeTime" component={ChangeTimeScreen} />
      <Stack.Screen name="ChangeDate" component={ChangeDateScreen} />
      <Stack.Screen name="AddGuests" component={AddGuestsScreen} />
    </Stack.Navigator>
  );
}

// Root Navigator - conditionally renders based on auth status
function RootNavigator() {
  const { isAuthenticated, isLoading } = useAuth();

  // Show loading while checking auth status
  if (isLoading) {
    return (
      <View style={{ flex: 1, backgroundColor: BackgroundColors.primary, justifyContent: 'center', alignItems: 'center' }}>
        <ActivityIndicator color={AccentColors.primary} size="large" />
      </View>
    );
  }

  // Show appropriate stack based on authentication
  return isAuthenticated ? <AppStack /> : <AuthStack />;
}

export default function App() {
  const fontsLoaded = useAppFonts();

  if (!fontsLoaded) {
    return (
      <View style={{ flex: 1, backgroundColor: BackgroundColors.primary, justifyContent: 'center', alignItems: 'center' }}>
        <ActivityIndicator color={AccentColors.primary} size="large" />
      </View>
    );
  }

  return (
    <AuthProvider>
      <NavigationContainer>
        <RootNavigator />
      </NavigationContainer>
    </AuthProvider>
  );
}
