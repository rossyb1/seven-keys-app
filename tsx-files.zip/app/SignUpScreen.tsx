import React, { useState } from 'react';
import {
  View,
  Text,
  TextInput,
  TouchableOpacity,
  StyleSheet,
  KeyboardAvoidingView,
  Platform,
  ScrollView,
  Image,
  Alert,
} from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import * as ImagePicker from 'expo-image-picker';
import { BrandColors, BackgroundColors, TextColors, AccentColors, Spacing, BorderRadius, Typography } from '../constants/brand';
import { ChevronLeft, ChevronRight } from '../components/icons/AppIcons';
import PrimaryButton from '../components/buttons/PrimaryButton';
import { createUser } from '../src/services/api';
import CountryCodePickerModal, { COUNTRIES, Country } from '../components/modals/CountryCodePickerModal';
import NationalityPickerModal, { NATIONALITIES, Nationality } from '../components/modals/NationalityPickerModal';

interface SignUpScreenProps {
  navigation: any;
  route: any;
}

export default function SignUpScreen({ navigation, route }: SignUpScreenProps) {
  const insets = useSafeAreaInsets();
  const inviteCode = route.params?.inviteCode || '';
  
  const [fullName, setFullName] = useState('');
  const [email, setEmail] = useState('');
  const [selectedCountry, setSelectedCountry] = useState<Country>(COUNTRIES[0]); // Default to UAE
  const [phoneNumber, setPhoneNumber] = useState('');
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [selectedNationality, setSelectedNationality] = useState<Nationality | null>(null);
  const [photoUri, setPhotoUri] = useState<string | null>(null);
  const [showCountryPicker, setShowCountryPicker] = useState(false);
  const [showNationalityPicker, setShowNationalityPicker] = useState(false);
  const [focusedField, setFocusedField] = useState<string | null>(null);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const validateEmail = (email: string): boolean => {
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return emailRegex.test(email);
  };

  const handlePhotoPicker = async () => {
    try {
      // Request permission
      const { status } = await ImagePicker.requestMediaLibraryPermissionsAsync();
      if (status !== 'granted') {
        Alert.alert(
          'Permission Required',
          'Please allow access to your photo library to add a profile photo.',
          [{ text: 'OK' }]
        );
        return;
      }

      // Launch image picker
      const result = await ImagePicker.launchImageLibraryAsync({
        mediaTypes: ImagePicker.MediaTypeOptions.Images,
        allowsEditing: true,
        aspect: [1, 1],
        quality: 0.8,
      });

      if (!result.canceled && result.assets[0]) {
        setPhotoUri(result.assets[0].uri);
      }
    } catch (err) {
      console.error('Error picking image:', err);
      Alert.alert('Error', 'Failed to pick image. Please try again.');
    }
  };

  const handleContinue = async () => {
    // Clear previous errors
    setError(null);
    console.log('🔄 Create account button pressed');

    // Validate all fields are filled
    if (!fullName.trim() || !email.trim() || !phoneNumber.trim() || !password || !confirmPassword) {
      setError('Please fill in all required fields');
      console.log('❌ Validation failed: missing fields');
      return;
    }

    // Validate email format
    if (!validateEmail(email)) {
      setError('Please enter a valid email address');
      console.log('❌ Validation failed: invalid email');
      return;
    }

    // Validate password match
    if (password !== confirmPassword) {
      setError('Passwords do not match');
      console.log('❌ Validation failed: passwords do not match');
      return;
    }

    // Validate password length (minimum 6 characters)
    if (password.length < 6) {
      setError('Password must be at least 6 characters');
      console.log('❌ Validation failed: password too short');
      return;
    }

    // Validate invite code exists
    if (!inviteCode) {
      setError('Invalid invite code. Please go back and enter a valid code.');
      console.log('❌ Validation failed: no invite code');
      return;
    }

    console.log('✅ All validations passed, calling createUser...');
    setIsSubmitting(true);

    try {
      // Combine country code with phone number
      const fullPhone = `${selectedCountry.dialCode}${phoneNumber.trim()}`;
      
      console.log('📞 Calling createUser with:', {
        email: email.trim(),
        full_name: fullName.trim(),
        phone: fullPhone,
        invite_code: inviteCode,
      });
      
      // Add timeout to prevent hanging
      const timeoutPromise = new Promise<{ user: any; error?: string }>((_, reject) =>
        setTimeout(() => reject(new Error('Request timed out. Please check your internet connection and try again.')), 15000)
      );

      const createUserPromise = createUser({
        email: email.trim(),
        full_name: fullName.trim(),
        phone: fullPhone,
        invite_code: inviteCode,
      });

      const result = await Promise.race([createUserPromise, timeoutPromise]);
      
      console.log('📥 createUser result:', result);

      if (result.error) {
        console.error('❌ createUser error:', result.error);
        // Show user-friendly error message
        let errorMessage = result.error;
        if (result.error.includes('Network') || result.error.includes('network') || result.error.includes('fetch')) {
          errorMessage = 'Network error. Please check your internet connection and try again. If the problem persists, Supabase may not be configured.';
        } else if (result.error.includes('Supabase is not configured')) {
          errorMessage = 'Supabase is not configured. Please check your .env file and restart the Expo server.';
        }
        setError(errorMessage);
      } else if (result.user) {
        console.log('✅ User created successfully, navigating to CitySelection');
        // Success - navigate to CitySelection
        navigation.navigate('CitySelection');
      } else {
        console.error('❌ createUser returned no user and no error');
        setError('Failed to create account. Please try again.');
      }
    } catch (err: any) {
      console.error('❌ Exception in handleContinue:', err);
      setError(err.message || 'Failed to create account. Please try again.');
    } finally {
      setIsSubmitting(false);
      console.log('🏁 handleContinue finished');
    }
  };

  return (
    <KeyboardAvoidingView
      style={styles.container}
      behavior={Platform.OS === 'ios' ? 'padding' : 'height'}
    >
      <TouchableOpacity
        style={styles.backButton}
        onPress={() => navigation.goBack()}
      >
        <ChevronLeft size={24} color={TextColors.primary} strokeWidth={1.5} />
      </TouchableOpacity>

      <ScrollView
        style={styles.scrollView}
        contentContainerStyle={styles.scrollContent}
        showsVerticalScrollIndicator={false}
      >
        <View style={styles.formContainer}>
          <Text style={styles.headline}>Create your profile</Text>

          <View style={styles.photoSection}>
            <TouchableOpacity 
              style={styles.photoPlaceholder}
              onPress={handlePhotoPicker}
              disabled={isSubmitting}
            >
              <View style={styles.photoCircle}>
                {photoUri ? (
                  <Image source={{ uri: photoUri }} style={styles.photoImage} />
                ) : (
                  <Text style={styles.plusIcon}>+</Text>
                )}
              </View>
            </TouchableOpacity>
            <Text style={styles.photoLabel}>Tap to add photo</Text>
          </View>

          <TextInput
            style={[
              styles.input,
              focusedField === 'fullName' && styles.inputFocused,
              error && styles.inputError,
            ]}
            placeholder="Full Name"
            placeholderTextColor={TextColors.tertiary}
            value={fullName}
            onChangeText={(text) => {
              setFullName(text);
              setError(null);
            }}
            onFocus={() => setFocusedField('fullName')}
            onBlur={() => setFocusedField(null)}
            autoCapitalize="words"
            editable={!isSubmitting}
          />

          <TextInput
            style={[
              styles.input,
              focusedField === 'email' && styles.inputFocused,
              error && styles.inputError,
            ]}
            placeholder="Email"
            placeholderTextColor={TextColors.tertiary}
            value={email}
            onChangeText={(text) => {
              setEmail(text);
              setError(null);
            }}
            onFocus={() => setFocusedField('email')}
            onBlur={() => setFocusedField(null)}
            keyboardType="email-address"
            autoCapitalize="none"
            autoCorrect={false}
            editable={!isSubmitting}
          />

          {/* Phone Number with Country Code */}
          <View style={styles.phoneContainer}>
            <TouchableOpacity
              style={[
                styles.countryCodeButton,
                focusedField === 'phone' && styles.countryCodeButtonFocused,
                error && styles.countryCodeButtonError,
              ]}
              onPress={() => setShowCountryPicker(true)}
              disabled={isSubmitting}
            >
              <Text style={styles.countryFlag}>{selectedCountry.flag}</Text>
              <Text style={styles.countryDialCode}>{selectedCountry.dialCode}</Text>
              <ChevronRight 
                size={16} 
                color={TextColors.secondary} 
                strokeWidth={1.5}
                style={styles.chevronIcon}
              />
            </TouchableOpacity>
            <TextInput
              style={[
                styles.phoneInput,
                focusedField === 'phone' && styles.inputFocused,
                error && styles.inputError,
              ]}
              placeholder="501234567"
              placeholderTextColor={TextColors.tertiary}
              value={phoneNumber}
              onChangeText={(text) => {
                // Only allow numbers
                const numericText = text.replace(/[^0-9]/g, '');
                setPhoneNumber(numericText);
                setError(null);
              }}
              onFocus={() => setFocusedField('phone')}
              onBlur={() => setFocusedField(null)}
              keyboardType="phone-pad"
              editable={!isSubmitting}
            />
          </View>

          <TextInput
            style={[
              styles.input,
              focusedField === 'password' && styles.inputFocused,
              error && styles.inputError,
            ]}
            placeholder="Password"
            placeholderTextColor={TextColors.tertiary}
            value={password}
            onChangeText={(text) => {
              setPassword(text);
              setError(null);
            }}
            onFocus={() => setFocusedField('password')}
            onBlur={() => setFocusedField(null)}
            secureTextEntry={true}
            autoCapitalize="none"
            autoCorrect={false}
            editable={!isSubmitting}
          />

          <TextInput
            style={[
              styles.input,
              focusedField === 'confirmPassword' && styles.inputFocused,
              error && styles.inputError,
            ]}
            placeholder="Confirm Password"
            placeholderTextColor={TextColors.tertiary}
            value={confirmPassword}
            onChangeText={(text) => {
              setConfirmPassword(text);
              setError(null);
            }}
            onFocus={() => setFocusedField('confirmPassword')}
            onBlur={() => setFocusedField(null)}
            secureTextEntry={true}
            autoCapitalize="none"
            autoCorrect={false}
            editable={!isSubmitting}
          />

          {/* Nationality Picker */}
          <TouchableOpacity
            style={[
              styles.input,
              styles.pickerInput,
              focusedField === 'nationality' && styles.inputFocused,
            ]}
            onPress={() => {
              setShowNationalityPicker(true);
              setFocusedField('nationality');
            }}
            disabled={isSubmitting}
          >
            <View style={styles.pickerContent}>
              {selectedNationality ? (
                <>
                  <Text style={styles.pickerFlag}>{selectedNationality.flag}</Text>
                  <Text style={styles.pickerText}>{selectedNationality.name}</Text>
                </>
              ) : (
                <Text style={styles.pickerPlaceholder}>Nationality</Text>
              )}
              <ChevronRight 
                size={16} 
                color={TextColors.secondary} 
                strokeWidth={1.5}
                style={styles.chevronIcon}
              />
            </View>
          </TouchableOpacity>

          {error && (
            <Text style={styles.errorText}>{error}</Text>
          )}
        </View>
      </ScrollView>

      <View style={[styles.buttonContainer, { paddingBottom: insets.bottom + Spacing.base }]}>
        <PrimaryButton
          title={isSubmitting ? 'CREATING ACCOUNT...' : 'CONTINUE'}
          onPress={handleContinue}
          disabled={isSubmitting}
          style={{ width: '100%' }}
        />
      </View>

      {/* Country Code Picker Modal */}
      <CountryCodePickerModal
        visible={showCountryPicker}
        onClose={() => setShowCountryPicker(false)}
        selectedCountry={selectedCountry}
        onSelectCountry={setSelectedCountry}
      />

      {/* Nationality Picker Modal */}
      <NationalityPickerModal
        visible={showNationalityPicker}
        onClose={() => {
          setShowNationalityPicker(false);
          setFocusedField(null);
        }}
        selectedNationality={selectedNationality}
        onSelectNationality={setSelectedNationality}
      />
    </KeyboardAvoidingView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: BackgroundColors.primary,
  },
  backButton: {
    padding: Spacing.base,
    alignSelf: 'flex-start',
    paddingTop: Spacing.xl,
  },
  scrollView: {
    flex: 1,
  },
  scrollContent: {
    flexGrow: 1,
  },
  formContainer: {
    paddingHorizontal: Spacing.xl,
    paddingTop: Spacing.base,
  },
  buttonContainer: {
    paddingHorizontal: Spacing.xl,
    paddingTop: Spacing.base,
  },
  headline: {
    color: TextColors.primary,
    fontSize: Typography.fontSize.xl,
    fontWeight: '600',
    marginBottom: Spacing.xl * 2,
  },
  photoSection: {
    alignItems: 'center',
    marginBottom: Spacing.xl * 2,
  },
  photoPlaceholder: {
    alignItems: 'center',
  },
  photoCircle: {
    width: 100,
    height: 100,
    borderRadius: 50,
    backgroundColor: BackgroundColors.secondary,
    borderWidth: 1,
    borderColor: AccentColors.border,
    justifyContent: 'center',
    alignItems: 'center',
    overflow: 'hidden',
  },
  photoImage: {
    width: '100%',
    height: '100%',
  },
  plusIcon: {
    color: TextColors.secondary,
    fontSize: Typography.fontSize['2xl'],
    fontWeight: '300',
  },
  photoLabel: {
    color: TextColors.tertiary,
    fontSize: Typography.fontSize.sm,
    marginTop: Spacing.sm,
  },
  phoneContainer: {
    flexDirection: 'row',
    marginBottom: Spacing.lg,
  },
  countryCodeButton: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: BackgroundColors.secondary,
    borderWidth: 1,
    borderColor: AccentColors.border,
    borderRadius: BorderRadius.base,
    paddingHorizontal: Spacing.base,
    minHeight: 52,
    minWidth: 120,
    marginRight: Spacing.sm,
  },
  countryCodeButtonFocused: {
    borderColor: AccentColors.primary,
  },
  countryCodeButtonError: {
    borderColor: '#EF4444',
  },
  countryFlag: {
    fontSize: 20,
    marginRight: Spacing.xs,
  },
  countryDialCode: {
    color: TextColors.primary,
    fontSize: Typography.fontSize.base,
    fontWeight: '500',
    marginRight: Spacing.xs,
  },
  chevronIcon: {
    transform: [{ rotate: '90deg' }],
  },
  phoneInput: {
    flex: 1,
    backgroundColor: BackgroundColors.secondary,
    borderWidth: 1,
    borderColor: AccentColors.border,
    borderRadius: BorderRadius.base,
    padding: Spacing.base,
    color: TextColors.primary,
    fontSize: Typography.fontSize.base,
    minHeight: 52,
  },
  input: {
    backgroundColor: BackgroundColors.secondary,
    borderWidth: 1,
    borderColor: AccentColors.border,
    borderRadius: BorderRadius.base,
    padding: Spacing.base,
    color: TextColors.primary,
    fontSize: Typography.fontSize.base,
    marginBottom: Spacing.lg,
    minHeight: 52,
  },
  pickerInput: {
    padding: 0,
    justifyContent: 'center',
  },
  pickerContent: {
    flexDirection: 'row',
    alignItems: 'center',
    padding: Spacing.base,
  },
  pickerFlag: {
    fontSize: 20,
    marginRight: Spacing.sm,
  },
  pickerText: {
    flex: 1,
    color: TextColors.primary,
    fontSize: Typography.fontSize.base,
  },
  pickerPlaceholder: {
    flex: 1,
    color: TextColors.tertiary,
    fontSize: Typography.fontSize.base,
  },
  inputFocused: {
    borderColor: AccentColors.primary,
  },
  inputError: {
    borderColor: '#EF4444',
  },
  errorText: {
    color: '#EF4444',
    fontSize: Typography.fontSize.sm,
    marginBottom: Spacing.base,
    marginTop: -Spacing.md,
  },
});
