import React, { useState, useCallback } from 'react';
import { View, Text, StyleSheet, ScrollView, TouchableOpacity, StatusBar, Image, ActivityIndicator, Alert } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { useFocusEffect } from '@react-navigation/native';
import { LinearGradient } from 'expo-linear-gradient';
import { User, CreditCard, MapPin, Bell, Clock, MessageCircle, HelpCircle, LogOut, Trash2, ChevronRight } from 'lucide-react-native';
import { BrandColors, BackgroundColors, TextColors, AccentColors, Spacing, Typography, BorderRadius } from '../../constants/brand';
import { getUserProfile, signOut } from '../../src/services/api';
import { useAuth } from '../../src/contexts/AuthContext';
import type { User as UserType } from '../../src/types/database';

interface ProfileScreenProps {
  navigation: any;
}

const ACCOUNT_ITEMS = [
  { icon: User, label: 'Personal Details', screen: 'PersonalDetails' },
  { icon: CreditCard, label: 'Payment Methods', screen: 'PaymentMethods' },
  { icon: MapPin, label: 'Preferred Cities', screen: 'PreferredCities' },
  { icon: Bell, label: 'Notification Settings', screen: 'NotificationSettings' },
];

const POINTS_ITEMS = [
  { icon: Clock, label: 'Points History', screen: 'PointsHistory' },
];

const SUPPORT_ITEMS = [
  { icon: MessageCircle, label: 'Message Concierge', screen: 'MessageConcierge' },
  { icon: HelpCircle, label: 'FAQs', screen: 'FAQs' },
];

export default function ProfileScreen({ navigation }: ProfileScreenProps) {
  const insets = useSafeAreaInsets();
  const [user, setUser] = useState<UserType | null>(null);
  const [isLoading, setIsLoading] = useState(true);

  // Fetch user profile when screen comes into focus
  useFocusEffect(
    useCallback(() => {
      const fetchProfile = async () => {
        setIsLoading(true);
        try {
          const result = await getUserProfile();
          if (result.error) {
            console.error('Error fetching profile:', result.error);
          } else {
            setUser(result.user);
          }
        } catch (err: any) {
          console.error('Error fetching profile:', err);
        } finally {
          setIsLoading(false);
        }
      };

      fetchProfile();
    }, [])
  );

  // Helper function to get initials from name
  const getInitials = (name: string): string => {
    return name
      .split(' ')
      .map((n) => n[0])
      .join('')
      .toUpperCase()
      .slice(0, 2);
  };

  // Helper function to format tier name
  const formatTier = (tier: UserType['tier']): string => {
    const tierMap: Record<UserType['tier'], string> = {
      member: '7K Member',
      select: '7K Select Member',
      elite: '7K Elite Member',
      black: '7K Black Member',
    };
    return tierMap[tier] || '7K Member';
  };

  // Helper function to format member since date
  const formatMemberSince = (createdAt: string): string => {
    const date = new Date(createdAt);
    return date.toLocaleDateString('en-US', { month: 'long', year: 'numeric' });
  };

  // Handle sign out
  const handleSignOut = async () => {
    Alert.alert(
      'Sign Out',
      'Are you sure you want to sign out?',
      [
        { text: 'Cancel', style: 'cancel' },
        {
          text: 'Sign Out',
          style: 'destructive',
          onPress: async () => {
            try {
              // Call signOut from API service
              const result = await signOut();
              
              if (result.error) {
                Alert.alert('Error', result.error);
                return;
              }

              // The AuthContext's onAuthStateChange listener will automatically
              // catch the signOut event and update the auth state (set user to null)
              // This will cause App.tsx's RootNavigator to automatically switch
              // from AppStack to AuthStack, showing the login flow (Splash -> InviteCode)
              // No manual navigation reset needed - React will handle the stack switch
            } catch (error: any) {
              Alert.alert('Error', error.message || 'Failed to sign out');
            }
          },
        },
      ]
    );
  };

  // Handle navigation for menu items
  const handleMenuPress = (screen: string) => {
    if (screen === 'PersonalDetails') {
      navigation.navigate('PersonalDetails');
    } else if (screen === 'PaymentMethods') {
      navigation.navigate('PaymentMethods');
    } else if (screen === 'PreferredCities') {
      navigation.navigate('PreferredCities');
    } else if (screen === 'NotificationSettings') {
      navigation.navigate('NotificationSettings');
    } else if (screen === 'PointsHistory') {
      navigation.navigate('PointsHistory');
    } else if (screen === 'MessageConcierge') {
      navigation.navigate('MessageConcierge');
    } else if (screen === 'FAQs') {
      navigation.navigate('FAQs');
    }
  };
  
  return (
    <View style={styles.container}>
      <StatusBar barStyle="light-content" />
      <ScrollView 
        style={styles.content} 
        showsVerticalScrollIndicator={false}
        contentContainerStyle={{ paddingTop: insets.top + Spacing.base }}
      >
        <View style={styles.header}>
          <Text style={styles.title}>Profile</Text>
        </View>

        {/* Profile Header */}
        {isLoading ? (
          <View style={styles.loadingContainer}>
            <ActivityIndicator size="large" color={AccentColors.primary} />
          </View>
        ) : user ? (
          <View style={styles.profileHeader}>
            <View style={styles.avatarContainer}>
              <LinearGradient
                colors={[AccentColors.primary, '#4A75B5']}
                style={styles.avatarRing}
              >
                <View style={styles.avatar}>
                  {user.photo_url ? (
                    <Image
                      source={{ uri: user.photo_url }}
                      style={styles.avatarImage}
                      resizeMode="cover"
                    />
                  ) : (
                    <Text style={styles.avatarText}>
                      {getInitials(user.full_name)}
                    </Text>
                  )}
                </View>
              </LinearGradient>
            </View>
            <Text style={styles.name}>{user.full_name}</Text>
            <Text style={styles.email}>{user.email}</Text>
            {user.phone && <Text style={styles.phone}>{user.phone}</Text>}
            <Text style={styles.tier}>{formatTier(user.tier)}</Text>
            <Text style={styles.points}>
              {user.points_balance.toLocaleString()} points
            </Text>
            <Text style={styles.memberSince}>
              Member since {formatMemberSince(user.created_at)}
            </Text>
          </View>
        ) : (
          <View style={styles.errorContainer}>
            <Text style={styles.errorText}>Unable to load profile</Text>
          </View>
        )}

        <View style={styles.divider} />

        {/* Account Section */}
        <Text style={styles.sectionHeader}>ACCOUNT</Text>
        <View style={styles.menuList}>
          {ACCOUNT_ITEMS.map((item, index) => (
            <TouchableOpacity
              key={index}
              style={styles.menuItem}
              onPress={() => handleMenuPress(item.screen)}
            >
              <View style={styles.menuItemLeft}>
                <item.icon size={20} color={TextColors.secondary} strokeWidth={1.5} />
                <Text style={styles.menuItemText}>{item.label}</Text>
              </View>
              <ChevronRight size={20} color={TextColors.tertiary} strokeWidth={1.5} />
            </TouchableOpacity>
          ))}
          {/* The 7K Card */}
          <TouchableOpacity
            style={styles.menuItem}
            onPress={() => navigation.navigate('SevenKCard')}
          >
            <View style={styles.menuItemLeft}>
              <CreditCard size={20} color={TextColors.secondary} strokeWidth={1.5} />
              <Text style={styles.menuItemText}>The 7K Card</Text>
            </View>
            <ChevronRight size={20} color={TextColors.tertiary} strokeWidth={1.5} />
          </TouchableOpacity>
        </View>

        <View style={styles.divider} />

        {/* Points Section */}
        <Text style={styles.sectionHeader}>POINTS</Text>
        <View style={styles.menuList}>
          {POINTS_ITEMS.map((item, index) => (
            <TouchableOpacity
              key={index}
              style={styles.menuItem}
              onPress={() => handleMenuPress(item.screen)}
            >
              <View style={styles.menuItemLeft}>
                <item.icon size={20} color={TextColors.secondary} strokeWidth={1.5} />
                <Text style={styles.menuItemText}>{item.label}</Text>
              </View>
              <ChevronRight size={20} color={TextColors.tertiary} strokeWidth={1.5} />
            </TouchableOpacity>
          ))}
        </View>

        <View style={styles.divider} />

        {/* Support Section */}
        <Text style={styles.sectionHeader}>SUPPORT</Text>
        <View style={styles.menuList}>
          {SUPPORT_ITEMS.map((item, index) => (
            <TouchableOpacity
              key={index}
              style={styles.menuItem}
              onPress={() => handleMenuPress(item.screen)}
            >
              <View style={styles.menuItemLeft}>
                <item.icon size={20} color={TextColors.secondary} strokeWidth={1.5} />
                <Text style={styles.menuItemText}>{item.label}</Text>
              </View>
              <ChevronRight size={20} color={TextColors.tertiary} strokeWidth={1.5} />
            </TouchableOpacity>
          ))}
        </View>

        <View style={styles.divider} />

        {/* Log Out */}
        <TouchableOpacity style={styles.logOutButton} onPress={handleSignOut}>
          <LogOut size={18} color={TextColors.secondary} strokeWidth={1.5} />
          <Text style={styles.logOutText}>Sign Out</Text>
        </TouchableOpacity>

        {/* Delete Account */}
        <TouchableOpacity style={styles.deleteAccountButton}>
          <Trash2 size={16} color={TextColors.tertiary} strokeWidth={1.5} />
          <Text style={styles.deleteAccountText}>Delete Account</Text>
        </TouchableOpacity>
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: BackgroundColors.primary,
  },
  content: {
    flex: 1,
    paddingHorizontal: Spacing.xl,
  },
  header: {
    marginBottom: Spacing.xl,
  },
  title: {
    color: TextColors.primary,
    fontSize: Typography.fontSize['2xl'],
    fontFamily: Typography.fontFamily.light,
  },
  profileHeader: {
    alignItems: 'center',
    marginBottom: Spacing.xl,
  },
  avatarContainer: {
    alignItems: 'center',
    marginBottom: Spacing.base,
  },
  avatarRing: {
    width: 88,
    height: 88,
    borderRadius: 44,
    justifyContent: 'center',
    alignItems: 'center',
  },
  avatar: {
    width: 80,
    height: 80,
    borderRadius: 40,
    backgroundColor: BackgroundColors.cardBg,
    justifyContent: 'center',
    alignItems: 'center',
  },
  avatarText: {
    color: TextColors.primary,
    fontSize: 24,
    fontWeight: '600',
  },
  avatarImage: {
    width: '100%',
    height: '100%',
    borderRadius: 40,
  },
  name: {
    color: TextColors.primary,
    fontSize: Typography.fontSize.xl,
    fontFamily: Typography.fontFamily.light,
    marginBottom: Spacing.xs / 2,
  },
  email: {
    color: TextColors.secondary,
    fontSize: Typography.fontSize.sm,
    marginBottom: Spacing.xs / 2,
  },
  phone: {
    color: TextColors.secondary,
    fontSize: Typography.fontSize.sm,
    marginBottom: Spacing.xs,
  },
  tier: {
    color: TextColors.secondary,
    fontSize: Typography.fontSize.base,
    marginBottom: Spacing.xs,
  },
  points: {
    color: AccentColors.primary,
    fontSize: Typography.fontSize.base,
    fontWeight: '500',
    marginBottom: Spacing.xs,
  },
  memberSince: {
    color: TextColors.tertiary,
    fontSize: Typography.fontSize.sm,
  },
  loadingContainer: {
    alignItems: 'center',
    paddingVertical: Spacing.xl * 2,
  },
  errorContainer: {
    alignItems: 'center',
    paddingVertical: Spacing.xl * 2,
  },
  errorText: {
    color: TextColors.secondary,
    fontSize: Typography.fontSize.base,
  },
  divider: {
    height: 1,
    backgroundColor: AccentColors.border,
    marginVertical: Spacing.xl,
  },
  sectionHeader: {
    color: TextColors.secondary,
    fontSize: Typography.fontSize.xs,
    fontWeight: '600',
    letterSpacing: 2,
    marginBottom: Spacing.base,
  },
  menuList: {
    marginBottom: Spacing.sm,
  },
  menuItem: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    backgroundColor: BackgroundColors.cardBg,
    borderWidth: 1,
    borderColor: 'rgba(86, 132, 196, 0.1)',
    borderRadius: 12,
    padding: Spacing.base,
    minHeight: 56,
    marginBottom: Spacing.sm,
  },
  menuItemLeft: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  menuItemText: {
    color: TextColors.primary,
    fontSize: Typography.fontSize.base,
    fontWeight: '500',
    marginLeft: Spacing.base,
  },
  logOutButton: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: Spacing.base,
    marginBottom: Spacing.base,
  },
  logOutText: {
    color: TextColors.secondary,
    fontSize: Typography.fontSize.base,
    marginLeft: Spacing.sm,
  },
  deleteAccountButton: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: Spacing.base,
    marginBottom: Spacing.xl * 2,
  },
  deleteAccountText: {
    color: TextColors.tertiary,
    fontSize: Typography.fontSize.sm,
    marginLeft: Spacing.sm,
  },
});
