import React, { useEffect, useState } from 'react';
import {
  View,
  Text,
  TouchableOpacity,
  StyleSheet,
  ActivityIndicator,
} from 'react-native';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { BrandColors, BackgroundColors, TextColors, AccentColors, Spacing, BorderRadius, Typography } from '../constants/brand';
import PrimaryButton from '../components/buttons/PrimaryButton';
import SevenKCard from '../components/cards/SevenKCard';
import { useAuth } from '../src/contexts/AuthContext';
import { getUserProfile } from '../src/services/api';

interface WelcomeScreenProps {
  navigation: any;
  route: any;
}

export default function WelcomeScreen({ navigation, route }: WelcomeScreenProps) {
  const { isAuthenticated, user: authUser } = useAuth();
  const [userName, setUserName] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState(true);

  // Try to get user name from multiple sources
  useEffect(() => {
    const fetchUserName = async () => {
      setIsLoading(true);
      
      // Priority 1: Check route params (if passed from signup flow)
      if (route.params?.fullName) {
        setUserName(route.params.fullName);
        setIsLoading(false);
        return;
      }

      // Priority 2: Check auth context (user should be authenticated by now)
      if (authUser?.full_name) {
        setUserName(authUser.full_name);
        setIsLoading(false);
        return;
      }

      // Priority 3: Fetch from API as fallback
      try {
        const result = await getUserProfile();
        if (result.user?.full_name) {
          setUserName(result.user.full_name);
        } else {
          // Fallback to 'Member' if no name found
          setUserName('Member');
        }
      } catch (error) {
        console.error('Error fetching user profile:', error);
        setUserName('Member');
      } finally {
        setIsLoading(false);
      }
    };

    fetchUserName();
  }, [route.params?.fullName, authUser]);

  // Get first name only for greeting
  const firstName = userName ? userName.split(' ')[0] : 'Member';
  const fullName = userName || 'Member';
  const memberTier = authUser?.tier || route.params?.memberTier || 'member';

  // When user becomes authenticated, RootNavigator will automatically switch to AppStack
  // This effect ensures smooth transition when auth state updates
  useEffect(() => {
    if (isAuthenticated) {
      // User is authenticated - RootNavigator will show AppStack automatically
      // The navigation will switch from AuthStack to AppStack automatically
      // No need to manually navigate - the RootNavigator handles this
    }
  }, [isAuthenticated]);
  
  const handleEnter = async () => {
    // User is authenticated at this point (after completing signup)
    // Mark onboarding as complete in AsyncStorage
    try {
      await AsyncStorage.setItem('hasCompletedOnboarding', 'true');
    } catch (error) {
      console.error('Error saving onboarding status:', error);
    }
    
    // The RootNavigator in App.tsx conditionally shows AuthStack or AppStack
    // based on isAuthenticated. Since the user is authenticated, RootNavigator
    // should show AppStack (which contains MainTabs with "Home" as the first tab).
    //
    // If we're still seeing WelcomeScreen, it means RootNavigator is still showing AuthStack.
    // This shouldn't happen if isAuthenticated is true, but if it does, we need to
    // ensure the auth state is properly updated.
    //
    // The RootNavigator will automatically switch to AppStack when it detects
    // that isAuthenticated is true. Since the user just completed signup, they
    // should be authenticated, so RootNavigator should show AppStack automatically.
    //
    // If the switch hasn't happened yet, it's likely a timing issue. The auth state
    // change listener in AuthContext should trigger a re-render of RootNavigator,
    // which will then show AppStack.
  };

  if (isLoading) {
    return (
      <View style={styles.container}>
        <View style={styles.loadingContainer}>
          <ActivityIndicator size="large" color={AccentColors.primary} />
        </View>
      </View>
    );
  }

  return (
    <View style={styles.container}>
      <View style={styles.content}>
        <View style={styles.cardContainer}>
          <SevenKCard
            memberName={fullName.toUpperCase()}
            tier={memberTier}
            memberSince="2025"
          />
        </View>

        <View style={styles.welcomeContainer}>
          <Text style={styles.headline}>Welcome, {firstName}</Text>
          <Text style={styles.subtext}>Your membership awaits.</Text>

          <PrimaryButton
            title="ENTER"
            onPress={handleEnter}
            style={{ width: '100%' }}
          />
        </View>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: BackgroundColors.primary,
  },
  content: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    paddingHorizontal: Spacing.xl,
  },
  cardContainer: {
    marginBottom: Spacing.xl * 2,
  },
  welcomeContainer: {
    alignItems: 'center',
    width: '100%',
  },
  headline: {
    color: TextColors.primary,
    fontSize: Typography.fontSize['2xl'],
    fontFamily: Typography.fontFamily.light,
    marginBottom: Spacing.sm,
    textAlign: 'center',
    letterSpacing: 1,
  },
  subtext: {
    color: TextColors.secondary,
    fontSize: Typography.fontSize.base,
    marginBottom: Spacing.xl * 2,
    textAlign: 'center',
    fontFamily: Typography.fontFamily.regular,
  },
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
});
